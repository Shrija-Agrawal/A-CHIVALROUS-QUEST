import pygame
import random

pygame.init()

SCREEN=(1200,750)
win=pygame.display.set_mode(SCREEN)
pygame.display.set_caption("GoodKnight")

#INITIALIZING VARIABLES:
#level 1:
fish_width=120
fish_height=50


#LOADING ALL THE IMAGES.

#Intro:
BACKGROUND_INTRO=[pygame.image.load("battleback1.png"),pygame.image.load("battleback2.png"),pygame.image.load("battleback3.png"),pygame.image.load("battleback4.png"),pygame.image.load("battleback5.png"),pygame.image.load("battleback6.png"),pygame.image.load("battleback7.png"),pygame.image.load("battleback8.png"),pygame.image.load("battleback9.png"),pygame.image.load("battleback10.png")]

#level1:
INTROBG=pygame.image.load("background.png")
BACKGROUND=pygame.transform.scale(pygame.image.load('background.png'),(2000,750))
FISH=pygame.transform.scale(pygame.image.load('fish.png'),(fish_width,fish_height))
OBSTACLES=[pygame.image.load('boot.png'),pygame.image.load('pirate.png'),pygame.image.load('shark1.png'),pygame.image.load('shark2.png'),pygame.image.load('jellyfish.png')]
OBSTACLES2=[pygame.transform.scale(OBSTACLES[0],(100,100)),pygame.transform.scale(OBSTACLES[1],(100,150)),pygame.transform.scale(OBSTACLES[2],(200,100)),pygame.transform.scale((pygame.transform.flip(OBSTACLES[3],True,False)),(200,100)),pygame.transform.scale((pygame.transform.rotate(OBSTACLES[4],90)),(134,100))]

#level2:
BACKGROUND2=pygame.image.load("castle.jpg")
BACKGROUND2_small=pygame.transform.scale(BACKGROUND2,(SCREEN))
DRAGON=[pygame.image.load('drag1.png'),pygame.image.load('drag2.png'),pygame.image.load('drag3.png'),pygame.image.load('drag2.png')]
KNIGHT_IDLE=[pygame.image.load('idle0.png'),pygame.image.load('idle1.png'),pygame.image.load('idle2.png'),pygame.image.load('idle3.png'),pygame.image.load('idle4.png'),pygame.image.load('idle5.png'),pygame.image.load('idle6.png'),pygame.image.load('idle7.png'),pygame.image.load('idle8.png'),pygame.image.load('idle9.png')]
KNIGHT_WALK=[pygame.image.load('walk0.png'),pygame.image.load('walk1.png'),pygame.image.load('walk2.png'),pygame.image.load('walk3.png'),pygame.image.load('walk4.png'),pygame.image.load('walk5.png'),pygame.image.load('walk6.png'),pygame.image.load('walk7.png'),pygame.image.load('walk8.png'),pygame.image.load('walk9.png')]
KNIGHT_ATTACK=[pygame.image.load("attack0.png"),pygame.image.load("attack1.png"),pygame.image.load("attack2.png"),pygame.image.load("attack3.png"),pygame.image.load("attack4.png"),pygame.image.load("attack5.png"),pygame.image.load("attack6.png"),pygame.image.load("attack7.png"),pygame.image.load("attack8.png"),pygame.image.load("attack9.png")]
FIRE=[pygame.image.load('fire0.png'),pygame.image.load('fire1.png'),pygame.image.load('fire2.png')]


#LOADING ALL THE FONTS.
font=pygame.font.Font('freesansbold.ttf',32)    #fontstyle for buttons.
titlefont=pygame.font.Font('freesansbold.ttf',80)   #fontstyle for headings.


#Creating a list to display countdowns before starting the levels.
countdown=['3','2','1']


#DEFINING ALL THE COLORS:
WHITE=(255,255,255)
BLACK=(0,0,0)
RED=(255,0,0)
BLUE=(0,0,255)
BROWN=(67,62,49)
DARK_GREEN=(51, 153, 51)


#Function to display the title screen.
def introduction():

    #using 2 images to show the scrolling effect in bacckground.
    introbg1_x, introbg1_y = 0, 0   
    introbg2_x = SCREEN[0]
    bg1_num , bg2_num = random.randint(0,9) , random.randint(0,9)
    
    color = WHITE   
    exit_game = False

    while not exit_game:
        
        Lclick=False 
        mx,my=pygame.mouse.get_pos()    

        #displaying 2 images with reducing x-coordinate to give the scrolling background effect.
        win.blit(pygame.transform.scale(BACKGROUND_INTRO[bg1_num],(1200,750)),(introbg1_x,introbg1_y))
        win.blit(pygame.transform.scale(BACKGROUND_INTRO[bg2_num],(1200,750)),(introbg2_x,introbg1_y))
        introbg1_x-=2
        introbg2_x-=2

        #if the image goes out of screen, it is shifted to the right again. Also, the image is switched to another random image each time.
        if introbg1_x<=-1200:
            introbg1_x=SCREEN[0]
            bg1_num=random.randint(0,9)
        if introbg2_x<=-1200:
            introbg2_x=SCREEN[0]
            bg2_num=random.randint(0,9)
        
        for event in pygame.event.get():
            
            if event.type==pygame.QUIT:   #to exit the game.
                exit_game=True
                pygame.quit()
            if event.type==pygame.MOUSEBUTTONDOWN:      #if any mouse button is pressed.
                if event.button==1:                     
                   Lclick=True


    #DISPLAYING TEXT AND CLICKING BUTTONS.

        box_w,box_h=200,50    
        x=(SCREEN[0]-box_w)/2   
        y=(SCREEN[1]-box_h)/2+200  
        pygame.draw.rect(win,BLACK,(x,y,box_w,box_h))

        play=font.render("PLAY",True,color)     
        win.blit(play,(x+55,y+10))            

        title=titlefont.render("GOODKNIGHT",True,WHITE)
        win.blit(title,(350,200))

        #conditions for clicking the button.
        if mx>=x and mx<=x+box_w and my>=y and my<=y+box_h:
            color=RED                                           #to give the hovering effect of cursor.
            if Lclick:                                          
                intro_lvl1()                                    
                break
        else:
            color=WHITE     #changing the color of the text back to white after hovering.

        pygame.display.update()


#CREATING A FUNCTION FOR INTRODUCTION SCENE FOR LEVEL 1.
def intro_lvl1():
    
    Lclick=False
    cursor_x,cursor_y=20,20
    timer=0
    color=BLACK

    display_text=""
    displayed_text=[]
    text_x=20
    text_y=10
    letter_iterate=0

    end=False

    while not end:

        text_lvl1="NARRATOR:Meet Richard.\n He is a fish.\nRICHARD:Hello there.\nNARRATOR:Yes.He can talk.\nWhy? How? Here's the answer.\nRichard’s ancestors were appointed as the guardians of a very rare and \nbeautiful diamond, the ‘Great Ivy.’\nRICHARD:Ahhh.\nNARRATOR:Calm down Richard.\nHowever, there was a witch who stole Great Ivy and cursed \nRichard’s entire family to stay as fishes forever.\nRICHARD:Sighs.\nNARRATOR:But the witch’s spell can be broken. There is a wise old turtle who lives \nfaraway. He may help Richard after knowing his situation.\nRICHARD:But, I need some help.\nNARRATOR:Will you help Richard to break the spell and get Great Ivy back?\n USE SPACEBAR TO MOVE UP AND DOWN"
        
        pygame.time.delay(10)
        win.fill(BROWN)

        Lclick=False   
        mx,my=pygame.mouse.get_pos()

        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                end=True
                break
            if event.type==pygame.MOUSEBUTTONDOWN:
                if event.button==1:
                    Lclick=True
        
        
        #TO GIVE THE TYPEWRITER EFFECT.
        if timer%10==0:
            try:
                if text_lvl1[letter_iterate]=='\n':
                    displayed_text.insert(0,display_text)
                    display_text=""
                else:    
                    display_text+=text_lvl1[letter_iterate]
                letter_iterate+=1
            except:
                pass

        temp=text_y
        for text in displayed_text:
            win.blit(font.render(str(text),True,WHITE),(text_x,text_y+100))
            text_y+=50
        text_y=temp
           
        display_text_rendered=font.render(display_text,True,WHITE)
        win.blit(display_text_rendered,(text_x,cursor_y))

        
        #TO DISPLAY BLINKING CURSOR.
        cursor_x=display_text_rendered.get_width()
        cursor=font.render("|",True,WHITE)
        if (timer//50)%2==0:
            win.blit(cursor,(cursor_x,cursor_y))
        
        #to display the skip button.
        pygame.draw.rect(win,WHITE,(SCREEN[0]-230,SCREEN[1]-50,200,30))
        skip=font.render("SKIP  INTRO",True,color)
        win.blit(skip,(SCREEN[0]-230,SCREEN[1]-50))

        if mx>=SCREEN[0]-230 and mx<=SCREEN[0]-30 and my>=SCREEN[1]-50 and my<=SCREEN[1]-20:
            color=RED
            if Lclick:
                main()
                break
        else:
            color=BLACK

        timer+=1    #timer for giving the blinking effect of cursor.

        pygame.display.update()



#FUNCTION FOR LEVEL 1  (FISH GAME)
def main():

    bg_x=0
    bg_x2=BACKGROUND.get_width()
    
    x_pos,y_pos=50,300 
    y_change=0
    distance=0          #to keep track of distance bar at the top.

    img_nm=random.randint(0,4)              #to randomize the obstacles.
    img_x,img_y=1200,random.randint(0,600)

    Game_Over=False
    end=False

    while not Game_Over:

            pygame.time.delay(10)
            Lclick=False
            mx,my=pygame.mouse.get_pos()
            
            #scrolling background effect using 2 images.
            bg_x-=1.4
            bg_x2-=1.4
            if bg_x<BACKGROUND.get_width()*-1:
                bg_x=BACKGROUND.get_width()
            if bg_x2<BACKGROUND.get_width()*-1:
                bg_x2=BACKGROUND.get_width()
            
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    Game_Over=True
                if event.type==pygame.KEYDOWN:          
                    if event.key==pygame.K_SPACE :          #to give the upward movement of fish.
                        y_change=-6
                elif event.type==pygame.KEYUP:
                    if event.key==pygame.K_SPACE :          #to give the downward movement of fish when there is no activity from user.
                        y_change=3
                if event.type==pygame.MOUSEBUTTONDOWN:
                    if event.button==1:
                        Lclick=True

            #to restrict movement of fish within the screen.          
            y_pos+=y_change
            if y_pos>600: y_pos=600
            if y_pos<=0:  y_pos=0

            img_width=OBSTACLES2[img_nm].get_width()
            img_height=OBSTACLES2[img_nm].get_height()

            #checking for colisions
            if detect_collision(x_pos,y_pos,img_x,img_y,fish_width, fish_height, img_width,img_height):
                end=True

            #updating enemy position
            img_x-=3
            if img_x<(OBSTACLES2[img_nm].get_width()*-1):  
                img_x=1200
                img_y=random.randint(0,700)
                img_nm=random.randint(0,4)

            #updating images
            win.blit(BACKGROUND,(bg_x,0))
            win.blit(BACKGROUND,(bg_x2,0))
            win.blit(FISH,(x_pos,y_pos))
            win.blit(OBSTACLES2[img_nm],(img_x,img_y))
            
            #displaying game over.
            if end:
                Game_Over_Text()
                if Lclick==True and mx>=350 and mx<=550 and my>=400 and my<=450:
                    distance=0
                    main()
                    break
                if Lclick==True and mx>=650 and mx<=850 and my>=400 and my<=450:
                    introduction()
                    break
            else:
                distance+=0.2
                if distance>=600:   
                    distance=600       # player moves to the next level.
                    level2()
                    break


            pygame.draw.rect(win,WHITE,(300,20,600,30))
            pygame.draw.rect(win,BLACK,(300,20,distance,30))
            
            pygame.display.update()


#FUNCTION FOR LEVEL 2.
def level2():

    knight_x=0
    knight_y=SCREEN[1]-250
    knight_health=400
    count_idle, count_walk, count_attack=0,0,0

    fireballs=[]
    dragon_health=400
    count_dragon, count_fire, time_fire =0,0,0
    
    Walking=False
    Attacking=False
    Idle=True
    WalkL,WalkR=False,True

    countdown_intro=0
    intro=True
    end=False

    while not end:

        pygame.time.delay(10)
        
        win.blit(BACKGROUND2_small,(0,0))
        pygame.draw.rect(win,DARK_GREEN,(10,10,knight_health,30))
        pygame.draw.rect(win,RED,(SCREEN[0]-410,10,dragon_health,30))
        
        drag_width=DRAGON[count_dragon//20].get_width()*4
        drag_height=DRAGON[count_dragon//20].get_height()*4
        win.blit(pygame.transform.scale(DRAGON[count_dragon//20],(drag_width,drag_height)),(SCREEN[0]-drag_width,drag_height))

        count_dragon+=1
        if count_dragon==80: count_dragon=0
        
        #creating a list to display multiple fireballs at once.
        if time_fire%100==0:
            fireballs.append([SCREEN[0]-drag_width,random.randint(100,1000),0])
        time_fire+=1
        
        for fireball in fireballs:
            win.blit(pygame.transform.scale(FIRE[fireball[2]//5],(95,62)),(fireball[0],fireball[1]))
            fireball[0]-=5
            fireball[2]+=1
            if detect_collision(knight_x,knight_y,fireball[0],fireball[1],150,209,95,62):
                knight_health-=1
            if knight_health<=0:
                knight_health=0
                #Game_Over_Text()
                endfont=titlefont.render("GAME OVER",True,WHITE)
                win.blit(endfont,(350,250))
            if fireball[2]==15: fireball[2]=0
            if fireball[0]<-10: fireballs.pop(0)


        if intro:
            title=titlefont.render(countdown[countdown_intro//100],True,BLUE)
            HOWTO=titlefont.render("use left and right arrows to move and spacebar to attack",True,BLUE)
            win.blit(title,(600,200))
            win.blit(HOWTO,(100, 400))
            countdown_intro+=1
            if countdown_intro==300: intro=False
        
        else:
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    end=True
                    break
                if event.type==pygame.KEYDOWN:
                    if event.key==pygame.K_SPACE :
                        Attacking=True
                        Walking=False
                        Idle=False
                    elif event.key==pygame.K_RIGHT :
                        WalkR=True
                        WalkL=False
                        Walking=True
                        Idle=False
                    elif event.key==pygame.K_LEFT:
                        WalkL=True
                        WalkR=False
                        Walking=True
                        Idle=False
                    elif event.key==pygame.K_UP:
                        #put the feature to jump here
                        pass
                if event.type==pygame.KEYUP:
                    if event.key==pygame.K_RIGHT:
                        Walking=False
                        Idle=True
                    elif event.key==pygame.K_LEFT:
                        Walking=False
                        Idle=True
                    elif event.key==pygame.K_SPACE:
                        Attacking=False
                        Idle=True
                        Walking=False

        #displaying different movements based on user input.
        if Idle:
            if WalkR:
                win.blit(pygame.transform.scale(KNIGHT_IDLE[count_idle//5],(150,209)),(knight_x,knight_y))
            if WalkL:
                win.blit(pygame.transform.flip(pygame.transform.scale(KNIGHT_IDLE[count_idle//5],(150,209)),True,False),(knight_x,knight_y))
            count_idle+=1
            if count_idle==46: count_idle=0

        if Walking:
            if WalkR:
                if knight_x<=SCREEN[0]-drag_width-150:
                    knight_x+=10
                win.blit(pygame.transform.scale(KNIGHT_WALK[count_walk//5],(150,209)),(knight_x,knight_y))
            if WalkL:
                if knight_x>=0:
                    knight_x-=10
                win.blit(pygame.transform.flip(pygame.transform.scale(KNIGHT_WALK[count_walk//5],(150,209)),True,False),(knight_x,knight_y))
            
            count_walk+=1
            if count_walk==46: count_walk=0

        if Attacking and not Idle and not Walking:
            if WalkR:
                win.blit(pygame.transform.scale(KNIGHT_ATTACK[count_attack//5],(150,209)),(knight_x,knight_y))
            else:
                win.blit(pygame.transform.flip(pygame.transform.scale(KNIGHT_ATTACK[count_attack//5],(150,209)),True,False),(knight_x,knight_y))
            count_attack+=1
            if count_attack==46: count_attack=0
            if detect_collision(knight_x,knight_y,SCREEN[0]-drag_width,drag_height,150,209,drag_width,drag_height):
                dragon_health-=1.5

        if dragon_health<=0:
            dragon_health=0
            winner=titlefont.render("YOU WIN",True,WHITE)
            win.blit(winner,(380,250))

        pygame.display.update()


#FUNCTION TO DETECT ANY COLLISIONS.
def detect_collision(x_pos,y_pos,enemy_x,enemy_y,player_width,player_height,enemy_Width,enemy_Height):
    if ( ( x_pos+player_width>=enemy_x and x_pos+player_width<=enemy_x+enemy_Width ) or ( x_pos>=enemy_x and x_pos<=enemy_x+enemy_Width ) ):
        if ( (y_pos+player_height>=enemy_y and y_pos+player_height<=enemy_y+enemy_Height ) or ( y_pos<=enemy_y+enemy_Height and y_pos>enemy_y ) ):
            return True
    return False

#FUNCTION TO DISPLAY GAME OVER TEXT.
def Game_Over_Text():
    endfont=titlefont.render("GAME OVER",True,WHITE)
    win.blit(endfont,(350,250))
    pygame.draw.rect(win,WHITE,(350,400,200,50))
    pygame.draw.rect(win,WHITE,(650,400,200,50))
    playagain=font.render("PLAY AGAIN",True,BLACK)
    win.blit(playagain,(350,400))
    menu=font.render("MENU",True,BLACK)
    win.blit(menu,(650,400))

#calling the introduction function to start the program.
introduction()

pygame.quit()